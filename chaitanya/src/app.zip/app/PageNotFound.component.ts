import { Component } from '@angular/core';

@Component({
  selector: 'my-page-not-found',
  template: `<h1>Sorry this page is not available with us.</h1>`,
})
export class PageNotFoundComponent  {  }
