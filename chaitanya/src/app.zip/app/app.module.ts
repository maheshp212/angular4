import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {RouterModule, Routes} from '@angular/router'

import { AppComponent, HomeComponent }  from './app.component';
import { ProductComponent }  from './product.component';
import { FruitsComponent }  from './fruits.component';
import { PageNotFoundComponent }  from './PageNotFound.component';

const appRoutes:Routes = [
	{path:'', component:HomeComponent},
	{path:'product', component:ProductComponent},
	{path:'fruits', component:FruitsComponent},
	{path:'**', component:PageNotFoundComponent},
];

@NgModule({
  imports:      [ BrowserModule, RouterModule.forRoot(appRoutes) ],
  declarations: [ AppComponent, ProductComponent, FruitsComponent, PageNotFoundComponent, HomeComponent ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
