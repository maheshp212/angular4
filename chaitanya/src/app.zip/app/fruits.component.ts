import { Component } from '@angular/core';

@Component({
  selector: 'my-fruits',
  template: `<h1>Fruits Page</h1>`,
})
export class FruitsComponent  {  }
