import { Component } from '@angular/core';

@Component({
  selector: 'my-product',
  template: `<h1>Product Page</h1>`,
})
export class ProductComponent  {  }
